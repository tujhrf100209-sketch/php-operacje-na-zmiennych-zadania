# Zadania PHP – pętle i algorytmy

Rozwiązania zadań 1–15.

## Uruchomienie
W terminalu, w folderze projektu:
```bash
php 01_liczby_1_10.php
```

Zadania 5, 8, 9, 10, 11, 12, 13 i 14 pobierają dane od użytkownika przez `readline()`.
